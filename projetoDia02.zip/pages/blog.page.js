
export class BlogPage{
    txtFirstArticleTitle = $$('[id="main"] h2')[0];
}