import { Given, When, Then } from '@wdio/cucumber-framework';
import { expect, $ } from '@wdio/globals'
import { HeaderPage } from '../pages/header.page';
import { SearchResultPage } from '../pages/searchResult.page';
import { BlogPage } from '../pages/blog.page';

const header = new HeaderPage();
const searchResult = new SearchResultPage();
const blog = new BlogPage();

Given('I open the url', async () => {
    await browser.url('https://demos.bellatrix.solutions/'); //acessa o website
    await browser.maximizeWindow(); //maximiza o ecrã
});

When('I search by {string}', async (searchText) => {
  await header.search(searchText);
});

Then('the first product is {string}', async (productTitle) => {
    const firstProductTitle = searchResult.txtProductTitle[0]; //cria um elemento pegando o primeiro elemento da lista de elemento txtProductTitle

    await expect(firstProductTitle).toHaveText(productTitle);
});

Then('the second product is {string}', async (productTitle) => {
    const secondProductTitle = searchResult.txtProductTitle[1];

    await expect(secondProductTitle).toHaveText(productTitle);
});

When('I go to blog menu', async () => {
    await header.btnMenuBlog.click();
});

When('I search by the title of the first item in the blog', async () => {
    const textFirstArticleTitle = await blog.txtFirstArticleTitle.getText();
    await header.search(textFirstArticleTitle);
});

Then('I can see no products found message', async () => {
    await expect(searchResult.txtNotFoundProductMessage).toBeDisplayed();
});


